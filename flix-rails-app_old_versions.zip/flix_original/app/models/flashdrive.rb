class Flashdrive < ApplicationRecord
end
