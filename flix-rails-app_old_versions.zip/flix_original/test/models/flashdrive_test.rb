require 'test_helper'

class FlashdriveTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
